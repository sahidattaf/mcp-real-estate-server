properties = [
    {
        "id": "A302",
        "name": "Oceanview Resort Unit A302",
        "location": "Phuket, Thailand",
        "price": 480000,
        "type": "resort",
        "bedrooms": 3,
        "status": "available"
    },
    {
        "id": "B101",
        "name": "Mountainview Hotel Room B101",
        "location": "Chiang Mai, Thailand",
        "price": 220000,
        "type": "hotel",
        "bedrooms": 2,
        "status": "available"
    }
]