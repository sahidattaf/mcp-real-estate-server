# MCP Real Estate Server

A starter FastAPI MCP server for listing and searching properties. Designed to connect with Anything-LLM or other AI agents.

## Run Locally

```bash
pip install -r requirements.txt
uvicorn main:app --reload
```

Access the schema at: `http://localhost:8000/functions`