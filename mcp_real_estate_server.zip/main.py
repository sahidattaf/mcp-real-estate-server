from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Dict, Any
from functions import function_schema, handle_tool_call

app = FastAPI()

@app.get("/functions")
def get_functions():
    return function_schema

class ToolCall(BaseModel):
    function: str
    arguments: Dict[str, Any]

@app.post("/call")
def call_function(call: ToolCall):
    try:
        return handle_tool_call(call.function, call.arguments)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))