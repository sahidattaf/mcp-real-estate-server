from data import properties

function_schema = {
    "functions": [
        {
            "name": "list_properties",
            "description": "Lists all available properties.",
            "parameters": {"type": "object", "properties": {}}
        },
        {
            "name": "search_properties",
            "description": "Search properties by location, max price, or type.",
            "parameters": {
                "type": "object",
                "properties": {
                    "location": {"type": "string"},
                    "max_price": {"type": "number"},
                    "property_type": {"type": "string"}
                }
            }
        }
    ]
}

def handle_tool_call(func: str, args: dict):
    if func == "list_properties":
        return {"properties": properties}

    elif func == "search_properties":
        loc = args.get("location", "").lower()
        max_price = args.get("max_price", float("inf"))
        ptype = args.get("property_type", "").lower()

        results = [
            p for p in properties
            if (loc in p["location"].lower() if loc else True) and
               (p["price"] <= max_price) and
               (ptype in p["type"].lower() if ptype else True)
        ]
        return {"matches": results}

    raise ValueError("Unsupported function")